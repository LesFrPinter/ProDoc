USE [ESTIMATING]
GO

/****** Object:  Table [dbo].[ESTFORMTYPE]    Script Date: 11/8/2023 7:01:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ESTFORMTYPE](
	[FORM_ID] [nchar](2) NULL,
	[FORM] [nvarchar](15) NULL
) ON [PRIMARY]

GO

